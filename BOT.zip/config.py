# config.py

api_id = "20028561"
api_hash = "0f3793daaf4d3905e55b0e44d8719cad"
bot_token = "7205145628:AAGM-2RZBGa1YqY9i_cLICQyN6ULr3DKBxA"
MONGO_URL = "mongodb+srv://tgeopen:loniko0908@cluster0.c9efpo0.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
# Bot owner ID
OWNER_ID = 5630057244
DEV_USERS = [5630057244]
LOGGING_CHAT_ID = -1001890720099
ADMINS = 5630057244
spotify_client_id = "ea5056b8de21435296daa3ca6a9b1240"
spotify_client_secret = "e5071dc9dee54dfa94805c949cbc230f"
string_session = "BQExnJEAdS-TvVc7jCSQOwZGVRqzjxlEfgq_eHEM2dNfjzKcjYuS9_AaUGR2D0zMAKo8AojiTK4JaMvRxDQgAa9eY6sMmcyYCPfQCD3JbQhoV-RrZOUSnf4J_zpU-QEcnpReTQk6STH902_SqS588CKoVM4IW6uZkr2Xgucbasyy7N0vWztYw0Hep2Epny52L6xsSiqbgubUjhTwpBhweUGJeaUt8oILQQbfkrwrXYwSyySv6nI15YXiAjcawO9ZWNtf_hJDtdSJCnM6CebLd3mjmd0FmwsOalqhpElerFWS7iojTRwPsKDUEpGy70CICipUMQBdsJHXtbAQ5LV_NkbnGoJY3QAAAAFoGf4uAA"
genius_api_token = "SjWQj7eNituIpjJwD_cPey40Kx3cHZmTcVdaewuP61nYPyd5f623zMiKLQvoJI30"
wibu_api_key = "WIBUAPI-qgU5lmAoKGHSTDqDZ7JQsqtmj6l7YSVr2AfsU-mcvTHNC41621dWp999Ygn85VZicw5stPUflkp7iNMVE47ADGPJV0DGiPQTo6BW-A"
# config.py
OWNER_IDS = [5630057244, 6682158027]  # Bot owner's Telegram IDs
