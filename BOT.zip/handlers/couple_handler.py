# handlers/couple_handler.py

from ..features.couple import nibba_nibbi
