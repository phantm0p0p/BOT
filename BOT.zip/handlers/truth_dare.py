import requests
from pyrogram import Client, filters
from ..bot import bot

@bot.on_message(filters.command("truth"))
async def truth(client, message):
    params = {
        "rating": "pg13"  # Change this to "pg" or "r" if needed
    }
    truth_response = requests.get("https://api.truthordarebot.xyz/v1/truth", params=params).json()
    truth = truth_response.get("question")
    await message.reply_text(truth)

@bot.on_message(filters.command("dare"))
async def dare(client, message):
    params = {
        "rating": "pg13"  # Change this to "pg" or "r" if needed
    }
    dare_response = requests.get("https://api.truthordarebot.xyz/v1/dare", params=params).json()
    dare = dare_response.get("question")
    await message.reply_text(dare)

@bot.on_message(filters.command("wyr"))
async def wyr(client, message):
    params = {
        "rating": "pg13"  # Change this to "pg" or "r" if needed
    }
    wyr_response = requests.get("https://api.truthordarebot.xyz/v1/wyr", params=params).json()
    wyr = wyr_response.get("question")
    await message.reply_text(wyr)

@bot.on_message(filters.command("nhie"))
async def nhie(client, message):
    params = {
        "rating": "pg13"  # Change this to "pg" or "r" if needed
    }
    nhie_response = requests.get("https://api.truthordarebot.xyz/v1/nhie", params=params).json()
    nhie = nhie_response.get("question")
    await message.reply_text(nhie)

@bot.on_message(filters.command("paranoia"))
async def paranoia(client, message):
    params = {
        "rating": "pg13"  # Change this to "pg" or "r" if needed
    }
    paranoia_response = requests.get("https://api.truthordarebot.xyz/v1/paranoia", params=params).json()
    paranoia = paranoia_response.get("question")
    await message.reply_text(paranoia)

